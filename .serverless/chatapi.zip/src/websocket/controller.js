"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebSocketController = void 0;
const aws_sdk_1 = require("aws-sdk");
class WebSocketController {
    constructor() { }
    onConnect(event, context) {
        return __awaiter(this, void 0, void 0, function* () {
            let msg = 'Web Socket onConnect Event Fired';
            console.log(msg);
        });
    }
    onDisconnect(event, context) {
        return __awaiter(this, void 0, void 0, function* () {
            let msg = 'Web Socket onDisconnect Event Fired';
            console.log(msg);
        });
    }
    onHeartbeat(event, context) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let msg = 'Web Socket "heartbeat" Event Fired';
                console.log(msg);
                // Client Side ==> socket.send(obj);  ==> obj = {"action": "test", "msg": "Client Says Hi"}
                // event.body will be equal to obj
                // let msg = event.body.msg;
                let email = JSON.parse(event.body).message;
                let connectionId = event.requestContext.connectionId;
                var ddb = new aws_sdk_1.DynamoDB({ apiVersion: '2012-08-10' });
                console.log('messageFromClient : ', email);
                var params = {
                    TableName: 'connectedClientsTable',
                    Item: {
                        'email': { S: email },
                        'connectionId': { S: connectionId }
                    }
                };
                yield ddb.putItem(params).promise();
                let messageToClient = JSON.stringify({ clientMessage: email, connectionId: connectionId, type: "heartbeat" });
                const domain = event.requestContext.domainName;
                const stage = event.requestContext.stage;
                const callbackUrlForAWS = `https://${domain}/${stage}`;
                yield this.sendMessageToClient(callbackUrlForAWS, connectionId, messageToClient);
            }
            catch (error) {
                console.error('Error Occurred While Posting Message Back to Client : ', error);
            }
        });
    }
    onNotify(event, context) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let msg = 'Web Socket "notify" Event Fired';
                console.log(msg);
                let clientPayload = JSON.parse(event.body);
                console.log('messageFromClient : ', clientPayload);
                let recipientKeys = clientPayload.recipients.map((r) => ({ "email": { S: r } }));
                let connectionId = event.requestContext.connectionId;
                var ddb = new aws_sdk_1.DynamoDB({ apiVersion: '2012-08-10' });
                var params = {
                    RequestItems: {
                        'connectedClientsTable': {
                            Keys: recipientKeys,
                            ProjectionExpression: 'email, connectionId'
                        }
                    }
                };
                let ddbResult = yield ddb.batchGetItem(params).promise();
                console.log('ddbResult : ', ddbResult);
                // let messageToClient = JSON.stringify({ clientMessage: email, connectionId: connectionId });
                const domain = event.requestContext.domainName;
                const stage = event.requestContext.stage;
                const callbackUrlForAWS = `https://${domain}/${stage}`;
                // await this.sendMessageToClient(callbackUrlForAWS, connectionId, messageToClient);
            }
            catch (error) {
                console.error('Error Occurred While Posting Message Back to Client : ', error);
            }
        });
    }
    sendMessageToClient(url, connectionId, msg) {
        return __awaiter(this, void 0, void 0, function* () {
            const apigatewaymanagementapi = new aws_sdk_1.ApiGatewayManagementApi({
                apiVersion: '2018-11-29',
                endpoint: url,
                region: 'ap-south-1'
            });
            return yield apigatewaymanagementapi.postToConnection({
                ConnectionId: connectionId,
                Data: Buffer.from(msg),
            }).promise();
        });
    }
}
exports.WebSocketController = WebSocketController;
//# sourceMappingURL=controller.js.map