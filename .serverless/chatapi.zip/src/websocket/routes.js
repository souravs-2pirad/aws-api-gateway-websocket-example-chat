"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const controller_1 = require("./controller");
function handler(event, context) {
    return __awaiter(this, void 0, void 0, function* () {
        console.log('Event : ', event);
        let wsController = new controller_1.WebSocketController();
        let successResponse = { statusCode: 200 };
        let errorResponse = { statusCode: 500 };
        try {
            let routeKey = event.requestContext.routeKey;
            switch (routeKey) {
                case '$connect':
                    yield wsController.onConnect(event, context);
                    break;
                case '$disconnect':
                    yield wsController.onDisconnect(event, context);
                    break;
                case 'heartbeat':
                    yield wsController.onHeartbeat(event, context);
                    break;
                case 'notify':
                    yield wsController.onNotify(event, context);
                    break;
                case '$default':
                    return { statusCode: 200, body: 'WS_WebSocketMirrorSuccessful' };
            }
            // Return a 200 status to tell API Gateway the message was processed
            // successfully.
            // Otherwise, API Gateway will return a 500 to the client.
            console.log('Websocket Success Response 200');
            return successResponse;
        }
        catch (error) {
            console.log('Websocket Error Occurred 500', error);
            return errorResponse;
        }
    });
}
exports.handler = handler;
//# sourceMappingURL=routes.js.map